﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using TouristGuide.Models;

namespace TouristGuide.Controllers
{
    public class TouristsController : ApiController
    {
        private TouristGuideContext db = new TouristGuideContext();

        // GET: api/Tourists
        public IQueryable<TouristDTO> GetTourists()
        {
            var tourists = from t in db.Tourists
                select new TouristDTO()
                {
                    Id = t.Id,
                    Location = t.Location,
                    CountryName = t.Country.Name
                };

            return tourists;
        }

        // GET: api/Tourists/5
        [ResponseType(typeof(TouristDetailDTO))]
        public async Task<IHttpActionResult> GetTourist(int id)
        {
            /*
            Tourist tourist = await db.Tourists.FindAsync(id);
            if (tourist == null)
            {
                return NotFound();
            }

            return Ok(tourist);
            */
            var tourist = await db.Tourists.Include(t => t.Country).Select(t =>
                new TouristDetailDTO()
                {
                    Id = t.Id,
                    Location = t.Location,
                    Itinerary = t.Itinerary,
                    Budget = t.Budget,
                    CountryName = t.Country.Name,
                    Type = t.Type
                }).SingleOrDefaultAsync(t => t.Id == id);
            if (tourist == null)
            {
                return NotFound();
            }

            return Ok(tourist);
        }

        // PUT: api/Tourists/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutTourist(int id, Tourist tourist)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tourist.Id)
            {
                return BadRequest();
            }

            db.Entry(tourist).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TourismExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Tourists
        [ResponseType(typeof(Tourist))]
        public async Task<IHttpActionResult> PostTourist(Tourist tourist)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Tourists.Add(tourist);
            await db.SaveChangesAsync();

            // New code:
            // Load author name
            db.Entry(tourist).Reference(x => x.Country).Load();

            var dto = new TouristDTO()
            {
                Id = tourist.Id,
                Location = tourist.Location,
                CountryName = tourist.Country.Name
            };


            return CreatedAtRoute("DefaultApi", new { id = tourist.Id }, dto);
        }

        // DELETE: api/Tourists/5
        [ResponseType(typeof(Tourist))]
        public async Task<IHttpActionResult> DeleteTourist(int id)
        {
            Tourist tourist = await db.Tourists.FindAsync(id);
            if (tourist == null)
            {
                return NotFound();
            }

            db.Tourists.Remove(tourist);
            await db.SaveChangesAsync();

            return Ok(tourist);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TourismExists(int id)
        {
            return db.Tourists.Count(e => e.Id == id) > 0;
        }
    }
}
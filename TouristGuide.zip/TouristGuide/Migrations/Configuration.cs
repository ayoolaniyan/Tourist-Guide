namespace TouristGuide.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using TouristGuide.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<TouristGuide.Models.TouristGuideContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(TouristGuide.Models.TouristGuideContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //
            context.Countries.AddOrUpdate(x => x.Id,
                new Country() { Id = 1, Name = "The Netherlands" },
                new Country() { Id = 2, Name = "France" },
                new Country() { Id = 3, Name = "Italy" },
                new Country() { Id = 4, Name = "London" },
                new Country() { Id = 5, Name = "United States" }
            );

            context.Tourists.AddOrUpdate(x => x.Id,
                new Tourist()
                {
                    Id = 1,
                    Location = "Amsterdam",
                    Itinerary = "Vacation Package",
                    CountryId = 1,
                    Budget = 9.99M,
                    Type = "Vacation"
                },
                new Tourist()
                {
                    Id = 2,
                    Location = "France",
                    Itinerary = "Christmas Holiday Package",
                    CountryId = 2,
                    Budget = 12.95M,
                    Type = "Christmas Holiday"
                },
                new Tourist()
                {
                    Id = 3,
                    Location = "Italy",
                    Itinerary = "Religous Package",
                    CountryId = 3,
                    Budget = 15M,
                    Type = "Religous Vacation"
                },
                new Tourist()
                {
                    Id = 4,
                    Location = "London",
                    Itinerary = "Family Vacation Package",
                    CountryId = 4,
                    Budget = 8.95M,
                    Type = "Family Vacation"
                },
                new Tourist()
                {
                    Id = 5,
                    Location = "United States",
                    Itinerary = "Bachelor/Spinster Vacation Package",
                    CountryId = 5,
                    Budget = 8.95M,
                    Type = "Bachelor/Spinster Vacation"
                }
            );
        }
    }
}
